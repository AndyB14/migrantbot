import os
import time
import logging
import schedule
from telegram import Bot

# --- НАСТРОЙКИ ---
bot_token = os.getenv("BOT_TOKEN")
channel_to_post = os.getenv("CHANNEL")

# Источники — подгружаются с сайтов и других каналов позже
keywords = ["мигрант", "патент", "гражданство", "внж", "рвп", "штраф", "мвд", "экзамен"]
test_messages = [
    "Сегодня задержали нелегального мигранта без патента",
    "На границе ввели новые правила въезда",
    "Штрафы за отсутствие регистрации выросли в два раза"
]

# ЛОГИ
logging.basicConfig(filename='parser_log.txt', level=logging.INFO, format='%(asctime)s - %(message)s')
bot = Bot(token=bot_token)

def fetch_and_send():
    for message in test_messages:
        if any(keyword in message.lower() for keyword in keywords):
            try:
                bot.send_message(chat_id=channel_to_post, text=message)
                logging.info(f"✅ Отправлено: {message[:80]}...")
                print(f"✅ Отправлено: {message}")
                time.sleep(60)  # Ограничение: 1 сообщение в минуту
                break  # Отправляем только одно сообщение за цикл
            except Exception as e:
                logging.warning(f"❌ Ошибка при отправке: {e}")

schedule.every(10).minutes.do(fetch_and_send)

print("🚀 Бот запущен")
while True:
    schedule.run_pending()
    time.sleep(1)
